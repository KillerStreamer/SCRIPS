
local isCoordsToolActive = false

-- Register the command
RegisterCommand('devtoolscoords', function(source, args, rawCommand)
    isCoordsToolActive = not isCoordsToolActive -- Toggle the tool on/off
    if isCoordsToolActive then
        print("DevTools Coords: ON")
        StartCoordsTool()
    else
        print("DevTools Coords: OFF")
    end
end, false)

-- Main function for the coords tool
function StartCoordsTool()
    Citizen.CreateThread(function()
        while isCoordsToolActive do
            Citizen.Wait(0) -- Run every frame

            -- Get the player's camera coordinates and direction
            local playerPed = PlayerPedId()
            local camPos = GetGameplayCamCoord()
            local camRot = GetGameplayCamRot(2)
            local camDir = RotationToDirection(camRot)

            -- Calculate the target point (e.g., 100 units away from camera)
            local distance = 100.0
            local targetPos = camPos + (camDir * distance)

            -- Perform raycast to detect collision
            local rayHandle = StartExpensiveSynchronousShapeTestLosProbe(
                camPos.x, camPos.y, camPos.z,
                targetPos.x, targetPos.y, targetPos.z,
                -1, -- Collide with everything
                playerPed,
                0
            )
            local _, hit, endCoords, surfaceNormal, entityHit = GetShapeTestResult(rayHandle)

            -- If raycast hits something, use the collision point; otherwise, use the target point
            local finalPos = hit == 1 and endCoords or targetPos

            -- Draw a semi-transparent sphere at the final position
            DrawMarker(
                28, -- Sphere marker type
                finalPos.x, finalPos.y, finalPos.z,
                0.0, 0.0, 0.0, -- Direction (not used for sphere)
                0.0, 0.0, 0.0, -- Rotation
                0.2, 0.2, 0.2, -- Scale (small sphere)
                0, 255, 255, 100, -- Cyan color with 100 alpha for transparency
                false, -- Bob up and down
                true, -- Face camera
                2, -- P19 (usually 2 for markers)
                false, -- Rotate
                nil, nil, false -- Texture dict, texture name, draw on ents
            )

            -- Check if 'E' key is pressed (key code 38)
            if IsControlJustPressed(0, 38) then
                -- Format coordinates as a string
                local result = finalPos.x .. ", " .. finalPos.y .. ", " .. finalPos.z
                -- Copy to clipboard (requires a clipboard resource or native clipboard support)
                SendNUIMessage({
                    action = 'copy',
                    toCopy = result
                })
                print("Coordinates: " .. result)
            end
        end
    end)
end

-- Helper function to convert camera rotation to direction vector
function RotationToDirection(rotation)
    local z = math.rad(rotation.z)
    local x = math.rad(rotation.x)
    local num = math.abs(math.cos(x))
    return vector3(
        -math.sin(z) * num,
        math.cos(z) * num,
        math.sin(x)
    )
end
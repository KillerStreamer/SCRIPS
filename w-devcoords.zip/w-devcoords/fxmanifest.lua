fx_version 'cerulean'
game 'gta5'

author ''
description ''
version '1.0.0'

client_script {
    '@w-interact/init.lua',
    'client/*.lua',
}
server_script 'server/*.lua'
shared_script 'shared/*.lua'

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/script.js',
}

client_scripts {
    "stream/hud_reticle.gfx",
    "stream/minimap.gfx",
}

server_script '@oxmysql/lib/MySQL.lua'